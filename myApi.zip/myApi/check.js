var mysql = require('mysql');

var con = mysql.createConnection({
  host: "35.200.193.123",
  user: "sakshi",
  password: "summer2020"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});