const mysql = require('mysql');

// Database Connection for Production

 let config = {
     host:process.env.SQL_HOST,
     user:process.env.SQL_USER,
     database:process.env.SQL_DATABASE,
     password:process.env.SQL_PASSWORD,
     socketPath:`/cloudsql/${process.env.INSTANCE_CONNECTION_NAME}`
 
 }


  

 let connection = mysql.createConnection(config);

 connection.connect(function(err) {
  if (err) {
    console.error('Error connecting: ' + err.stack);
    return;
  }
  console.log('Connected as thread id: ' + connection.threadId);
});

//module.exports = connection;
//con=connection.connect();
exports.con=connection;